import streamlit as st
import pandas as pd
import numpy as np
import pickle
import xgboost as xgb

# Load the optimized XGBoost model
with open("optimized_xgb_model.pkl", "rb") as file:
    model = pickle.load(file)

# Load selected feature names
df_features = pd.read_csv("final_selected_features.csv")
selected_features = df_features.columns.tolist()

# Remove 'Caloric Value' if present
if "Caloric Value" in selected_features:
    selected_features.remove("Caloric Value")

# Load encoded food dataset
food_data = pd.read_csv("encoded_food_data.csv")

# Ensure dataset matches model features
missing_features = set(selected_features) - set(food_data.columns)
extra_features = set(food_data.columns) - set(selected_features)
food_data = food_data[selected_features]  # Keep only necessary features

# Load cleaned food dataset for diet plan recommendations
cleaned_food_data = pd.read_csv("cleaned_food_data.csv")

# Streamlit UI
st.title("AI-Based Personalized Diet Recommendation System")

# User Inputs
weight = st.number_input("Enter your weight (kg)", min_value=55, max_value=200, step=1)
height = st.number_input("Enter your height (cm)", min_value=160, max_value=250, step=1)
lifestyle = st.selectbox("Select your lifestyle", ["Sedentary", "Lightly Active", "Moderately Active", "Very Active"])
goal = st.selectbox("Select your goal", ["Fat Loss", "Muscle Gain"])

# Function to recommend a diet plan
def recommend_diet(calories, protein_needed):
    # Filter food items within 10% of required calories
    suitable_foods = cleaned_food_data[
        (cleaned_food_data["Caloric Value"] >= calories * 0.9) &
        (cleaned_food_data["Caloric Value"] <= calories * 1.1)
    ]
    
    # Sort by protein for muscle gain or by fiber for fat loss
    if goal == "Muscle Gain":
        suitable_foods = suitable_foods.sort_values(by="Protein", ascending=False)
    else:
        suitable_foods = suitable_foods.sort_values(by="Dietary Fiber", ascending=False)
    
    return suitable_foods.head(5)[["food", "Caloric Value", "Protein", "Dietary Fiber"]]

# Calculate BMR and Daily Caloric Intake
if st.button("📊 Generate Diet Plan"):
    if weight and height:
        # Baseline BMR (Mifflin-St Jeor Equation for Male, assuming age 25)
        bmr = 10 * weight + 6.25 * height - 5 * 25 + 5  
        activity_factor = {"Sedentary": 1.2, "Lightly Active": 1.375, "Moderately Active": 1.55, "Very Active": 1.725}
        daily_caloric_intake = bmr * activity_factor[lifestyle]

        # Adjust for goal
        if goal == "Fat Loss":
            daily_caloric_intake *= 0.85  # 15% deficit
        elif goal == "Muscle Gain":
            daily_caloric_intake *= 1.15  # 15% surplus

        st.success(f"Recommended Daily Caloric Intake: {daily_caloric_intake:.2f} kcal")

        # Protein Intake Recommendation for Muscle Gain
        protein_intake = weight * 2 if goal == "Muscle Gain" else 0  # 2g protein per kg
        if goal == "Muscle Gain":
            st.info(f"**Recommended Daily Protein Intake:** {protein_intake:.2f} g")

        # Recommend a diet plan
        diet_plan = recommend_diet(daily_caloric_intake, protein_intake)
        st.write("🍽️ **Recommended dishes to fullfill the calorie intake:**")
        st.dataframe(diet_plan)

        # Prepare input for model prediction
        input_features = np.zeros(len(selected_features))  # Create empty array
        input_df = pd.DataFrame([input_features], columns=selected_features)

        # Predict AI-based caloric intake
        predicted_calories = model.predict(input_df)[0]
        #st.write(f"🤖 **AI Predicted Caloric Intake:** {predicted_calories:.2f} kcal")

    else:
        st.error("❗ Please enter valid weight and height!")
